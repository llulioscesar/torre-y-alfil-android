package co.jcesar.torreyalfil;

import androidx.appcompat.app.AppCompatActivity;
import co.jcesar.torreyalfil.clases.Tablero;

import android.os.Bundle;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Tablero tablero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        tablero = new Tablero(this);
        final TextView consola = findViewById(R.id.consola);

        tablero.OnChangeFichaListener(new Tablero.OnChangeFicha() {
            @Override
            public void getFichaSeleccionada(String ficha) {
                if(!ficha.equals("")){
                    consola.setText(consola.getText()+ "\n" + ficha);
                    ((ScrollView) findViewById(R.id.scroll_console)).fullScroll(View.FOCUS_DOWN);
                }
            }
        });
    }

}
