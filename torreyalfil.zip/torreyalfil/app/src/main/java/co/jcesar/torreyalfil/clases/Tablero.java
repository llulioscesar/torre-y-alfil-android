package co.jcesar.torreyalfil.clases;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.gridlayout.widget.GridLayout;
import co.jcesar.torreyalfil.R;

/**
 * Esta clase define el tablero de juego
 * @author Julio Cesar Caicedo Santos
 * @version 30/03/2019
 */
public class Tablero {

    private OnChangeFicha mOnChangeFichaListener;
    public interface OnChangeFicha{
        public void getFichaSeleccionada(String ficha);
    }
    public void OnChangeFichaListener(OnChangeFicha eventListener){
        mOnChangeFichaListener = eventListener;
    }
    public void seleccionar(){
        if (mOnChangeFichaListener != null){
            String txt = "";
            if(seleccion != null){
                txt = seleccion.getFicha().getTipo().toString() + " => fila: " + (seleccion.getFila() +1) + " columna: " + (seleccion.getColumna() + 1);
            }

            mOnChangeFichaListener.getFichaSeleccionada(txt);
        }
    }

    private static final String TAG  = "TABLERO";

    GridLayout tablero;
    Activity app;
    Context context;

    ImageView[][] cuadros = new ImageView[8][8];

    Casilla seleccion = null;

    /**
     * Constructor para el tablero de ajedrez 8x8
     * @param context el parametro context define el contexto de la aplicacion donde se creara el tablero
     */
    public Tablero(Context context){
        this.app = (Activity) context;
        this.context = context;
        this.tablero = this.app.findViewById(R.id.tablero);
        boolean ok = false;

        GridLayout.LayoutParams layoutParams;

        DisplayMetrics metrics = new DisplayMetrics();
        app.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = metrics.widthPixels;
        int size = width / 9;

        for (int i = 0; i < 9; i++){
            for (int j = 0; j < 9; j++){
                Log.i(TAG, i +","+j);
                layoutParams = new GridLayout.LayoutParams();
                layoutParams.rowSpec = GridLayout.spec(i);
                layoutParams.columnSpec = GridLayout.spec(j);
                layoutParams.width = size;
                layoutParams.height = layoutParams.width;
                if(j>0&&i>0){
                    Log.i(TAG, (ok ? Casilla.Color.NEGRO : Casilla.Color.BLANCO).toString() + " " + ok);
                    ImageView cuadro = new ImageView(app);
                    cuadro.setOnClickListener(cuadroClick());
                    cuadro.setTag(new Casilla(ok ? Casilla.Color.NEGRO : Casilla.Color.BLANCO, i,j, null));
                    cuadro.setLayoutParams(layoutParams);
                    cuadro.setBackgroundColor(this.app.getResources().getColor(ok ? R.color.gris : R.color.blanco));
                    this.tablero.addView(cuadro);
                    this.cuadros[i-1][j-1] = cuadro;
                    if (j-1 != 7){
                        ok = !ok;
                    }
                }else if(i == 0 && j > 0){
                    TextView textView = new TextView(context);
                    textView.setGravity(Gravity.CENTER);
                    textView.setLayoutParams(layoutParams);
                    textView.setTextSize(18*width);
                    textView.setText(j+"");
                    this.tablero.addView(textView);
                } else if (i> 0) {
                    TextView textView = new TextView(context);
                    textView.setGravity(Gravity.CENTER);
                    textView.setLayoutParams(layoutParams);
                    textView.setText(i+"");
                    this.tablero.addView(textView);
                }
            }
        }
        ConstraintLayout.LayoutParams lp = (ConstraintLayout.LayoutParams)this.tablero.getLayoutParams();
        lp.height = width;
        this.tablero.setLayoutParams(lp);
        this.reiniciar();
    }

    /**
     * Este metodo coloca las fichas en el tablero en la posicion inicial de cada una
     */
    public void reiniciar(){

    }

    public View.OnClickListener cuadroClick(){
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageView cuadro = (ImageView) v;
                Casilla casilla = (Casilla) cuadro.getTag();
                if (casilla.getFicha() != null){
                    Ficha ficha = casilla.getFicha();
                    if(ficha.isMaquina()) return;
                    reestablecerColor();
                    seleccion = casilla;
                    seleccionar();
                    cuadro.setBackgroundColor(app.getResources().getColor(R.color.select));
                    if (ficha.getTipo() == Ficha.Tipo.ALFIL){
                        indicarDiagonal();
                    }


                }
            }
        };
    }

    /**
     * Muestra hacia donde puede mover la ficha
     */
    void indicarDiagonal(){
        int fila = seleccion.getFila();
        int columna = seleccion.getColumna();
        //parte izquierda abajo
        int valorFila = fila +1;
        int valorColumna = columna -1;
        while (valorFila < 8 && valorColumna >= 0){
            cuadros[valorFila][valorColumna].setBackgroundColor(app.getResources().getColor(R.color.select));
            valorFila++;
            valorColumna--;
        }
        //parte derecha arriba
        valorFila = fila - 1;
        valorColumna = columna + 1;
        while (valorFila >= 0 && valorColumna < 8) {
            cuadros[valorFila][valorColumna].setBackgroundColor(app.getResources().getColor(R.color.select));
            valorFila--;
            valorColumna++;
        }
        //parte izquierda arriba
        valorFila = fila - 1;
        valorColumna = columna - 1;
        while (valorFila >= 0 && valorColumna >= 0) {
            cuadros[valorFila][valorColumna].setBackgroundColor(app.getResources().getColor(R.color.select));
            valorFila--;
            valorColumna--;
        }
        //parte derecha abajo
        valorFila = fila + 1;
        valorColumna = columna + 1;
        while (valorFila < 8 && valorColumna < 8) {
            cuadros[valorFila][valorColumna].setBackgroundColor(app.getResources().getColor(R.color.select));
            valorFila++;
            valorColumna++;
        }

    }

    /**
     * Reestablece los colores del tablero de ajedrez despues de seleccionar una ficha
     */
    void reestablecerColor(){
        for (ImageView[] fila: cuadros) {
            for (ImageView cuadro: fila){
                Casilla casilla = (Casilla) cuadro.getTag();
                cuadro.setBackgroundColor(app.getResources().getColor(casilla.getColor() == Casilla.Color.NEGRO ? R.color.gris : R.color.blanco));
            }
        }
    }

}
