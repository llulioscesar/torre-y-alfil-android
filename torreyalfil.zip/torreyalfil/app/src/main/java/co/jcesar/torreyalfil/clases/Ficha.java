package co.jcesar.torreyalfil.clases;

public class Ficha {

    public enum Tipo{TORRE,ALFIL}
    public enum Banda{BLANCA, NEGRA}

    private Banda banda;
    private Tipo tipo;
    private boolean maquina;

    public Ficha(){}

    public Ficha(Tipo tipo, Banda banda, boolean maquina){
        this.banda = banda;
        this.maquina = maquina;
        this.tipo = tipo;
    };

    public Banda getBanda() {
        return banda;
    }

    public void setBanda(Banda banda) {
        this.banda = banda;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public boolean isMaquina() {
        return maquina;
    }

    public void setMaquina(boolean maquina) {
        this.maquina = maquina;
    }
}
